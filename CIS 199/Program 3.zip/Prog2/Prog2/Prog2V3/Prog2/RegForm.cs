﻿//B9279
// Program 3
// CIS 199-02
// Due: 3/7/2017


// This application calculates the earliest registration date
// and time for an undergraduate student given their class standing
// and last name.
// Decisions based on UofL Fall/Summer 2017 Priority Registration Schedule
//This version of this program uses method, parallel and range matching to get 
//time based on last name letter.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        //Pre-Condition: First letter has to be a capital letter from A-Z
        //Post-Condition: Returns time associated with the first letter of last name

        //Days method
        private string GetRegistrationTime(char lastNameCh)
        {
        const string TIME1 = "8:30 AM";  // 1st time block
        const string TIME2 = "10:00 AM"; // 2nd time block
        const string TIME3 = "11:30 AM"; // 3rd time block
        const string TIME4 = "2:00 PM";  // 4th time block
        const string TIME5 = "4:00 PM";  // 5th time block

        //Array for times for Junior and Seniors
        string[] time = { TIME3, TIME4, TIME5, TIME1, TIME2 };
        //Array of letters for Juniors and Seniors
        char[] jrSr = { 'A', 'E', 'J', 'P', 'T' };

        //Array for times for Freshmen and Sophmores
        string[] timeTwo = { TIME5, TIME1, TIME2, TIME3, TIME4, TIME5, TIME1, TIME2, TIME3, TIME4 };
        //Array of letters for Freshmen and Sophomores
        char[] freshSoph = { 'A', 'C', 'E', 'G', 'J', 'M', 'P', 'R', 'T', 'W' };

            //Stars from end
            int index = jrSr.Length - 1;
            bool found = false;

            //if junior and senior is checked
            if (juniorRBtn.Checked || seniorRBtn.Checked)
            {
                //while index is greater than position
                while (index >= 0 && !found)
                {
                    //if first letter is greater than the letter in the jrSr array starting at the end, and if true
                    if (lastNameCh >= jrSr[index])
                        found = true;
                    //if not go to next letter to the left
                    else
                        index--;
                }
                //if true, return time with same index number
                return time[index];
            }
            //else if sophmore or freshman
            else
            {
                //while index is greater than position
                while (index >= 0 && !found)
                {
                    //if first letter is greater than the letter in freshSoph array starting at the end, and if true
                    if (lastNameCh >= freshSoph[index])
                        found = true;
                    //if not go to next letter to the left
                    else
                        index--;
                }
                //if true, return timeTwo with same index number
                return timeTwo[index];
            }
    }

    // Find and display earliest registration time
    private void findRegTimeBtn_Click(object sender, EventArgs e)
        {
            const string DAY1 = "March 29";  // 1st day of registration
            const string DAY2 = "March 30";  // 2nd day of registration
            const string DAY3 = "March 31";  // 3rd day of registration
            const string DAY4 = "April 3";   // 4th day of registration
            const string DAY5 = "April 4";   // 5th day of registration
            const string DAY6 = "April 5";   // 6th day of registration


            //Array for days
            string[] day = { DAY1, DAY2, DAY3, DAY4, DAY5, DAY6 };
           

            string lastNameStr;       // Entered last name
            char lastNameLetterCh;    // First letter of last name, as char
            string dateStr = "Error"; // Holds date of registration
            string timeStr = "Error"; // Holds time of registration
            bool isUpperClass;        // Upperclass or not?

            lastNameStr = lastNameTxt.Text;
            if (lastNameStr.Length > 0) // Empty string?
            {
                lastNameLetterCh = lastNameStr[0];   // First char of last name
                lastNameLetterCh = char.ToUpper(lastNameLetterCh); // Ensure upper case

                if (char.IsLetter(lastNameLetterCh)) // Is it a letter?
                {
                    isUpperClass = (seniorRBtn.Checked || juniorRBtn.Checked);

                    // Juniors and Seniors share same schedule but different days
                    if (isUpperClass)
                    {
                        if (seniorRBtn.Checked)
                            dateStr = day[0];
                        else // Must be juniors
                            dateStr = day[1];
                        //Calls method to get registration time based on last name letter
                            timeStr = GetRegistrationTime (lastNameLetterCh);
                     
                    }
                    // Sophomores and Freshmen
                    else // Must be soph/fresh
                    {
                        if (sophomoreRBtn.Checked)
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = day[3];
                            else // All other letters on previous day
                                dateStr = day[2];
                        }
                        else // must be freshman
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = day[5];
                            else // All other letters on previous day
                                dateStr = day[4];
                        }
                        //Calls method to get registration time based on last name letter
                        timeStr = GetRegistrationTime(lastNameLetterCh);
                    }

                    // Output results
                    dateTimeLbl.Text = dateStr + " at " + timeStr;
                }
                else // First char not a letter
                    MessageBox.Show("Make sure last name starts with a letter");
            }
            else // Empty textbox
                MessageBox.Show("Enter a last name!");
        }
    }
}
