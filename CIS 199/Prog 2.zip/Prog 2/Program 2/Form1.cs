﻿//B9279
//Program 2
//March 7
//CIS 199 -02
//This program displays the user's schedule date and time based on user's last name and selected classification.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class program2 : Form
    {
        public program2()
        {
            InitializeComponent();
        }
        //Confrim button is selected
        private void confirmButton_Click(object sender, EventArgs e)
        {
            //Declaring string as input and char
            string lastName = lastNameText.Text;
            char lastNameLetter = char.ToUpper(lastName[0]);
            //Get the first character and make it upper case


            //Freshman and Sophomore section of code
            //if last name starts with A or B and either freshman or sophomore is selected then time is 4
            if (lastNameLetter >= 'A' && lastNameLetter <= 'B' && (freshmanButton.Checked == true || sophomoreButton.Checked == true))
            {
                timeText.Text = ("4:00");

                //if freshman then date in red is displayed
                if (freshmanButton.Checked == true)
                {
                    dateText.Text = ("Tuesday, April 4");
                }
                //if sophomore then date in red is displayed
                if (sophomoreButton.Checked == true)
                {
                    dateText.Text = ("Friday, March 31");
                }
            }

            //if last name starts with C or D and either freshman or sophomore is selected then time is 8:30
            if (lastNameLetter >= 'C' && lastNameLetter <= 'D' && (freshmanButton.Checked == true || sophomoreButton.Checked == true))
            {
                timeText.Text = ("8:30");

                //if freshman then date in red is displayed
                if (freshmanButton.Checked == true)
                {
                    dateText.Text = ("Wednesday, April 5");
                }
                //if sophomore then date in red is displayed
                if (sophomoreButton.Checked == true)
                {
                    dateText.Text = ("Monday, April 3");
                }
            }

            //if last name starts with E or F and either frehsman or sophomore, time is 10
            if (lastNameLetter >= 'E' && lastNameLetter <= 'F' && (freshmanButton.Checked == true || sophomoreButton.Checked == true))
            {
                timeText.Text = ("10:00");

                //if freshman is selected then date in red is displayed
                if (freshmanButton.Checked == true)
                {
                    dateText.Text = ("Wednesday, April 5");
                }
                //if sophomore is selected then date in red is displayed
                if (sophomoreButton.Checked == true)
                {
                    dateText.Text = ("Monday, April 3");
                }
            }

            //if last name starts with G or I and either freshman or sophomore, time is 11:30
            if (lastNameLetter >= 'G' && lastNameLetter <= 'I' && (freshmanButton.Checked == true || sophomoreButton.Checked == true))
            {
                timeText.Text = ("11:30");

                //if freshman, date in red is displayed
                if (freshmanButton.Checked == true)
                {
                    dateText.Text = ("Wedneday, April 5");
                }
                //if sophmore, date in red is displayed
                if (sophomoreButton.Checked == true)
                {
                    dateText.Text = ("Monday, April 3");
                }
            }

            //if last name starts with J or L and either freshman or sophomore, time is 2
            if (lastNameLetter >= 'J' && lastNameLetter <= 'L' && (freshmanButton.Checked == true || sophomoreButton.Checked == true))
            {
                timeText.Text = ("2:00");

                //if freshman, date in red is displayed
                if (freshmanButton.Checked == true)
                {
                    dateText.Text = ("Wednesday, April 5");
                }
                //if sophomore date in red is displayed
                if (sophomoreButton.Checked == true)
                {
                    dateText.Text = ("Monday, April 3");
                }
            }

            //if last name starts with M or O and either freshman or sophomore, time is 4
            if (lastNameLetter >= 'M' && lastNameLetter <= 'O' && (freshmanButton.Checked == true || sophomoreButton.Checked == true))
            {
                timeText.Text = ("4:00");

                //if freshman, date in red is displayed
                if (freshmanButton.Checked == true)
                {
                    dateText.Text = ("Wednesday, April 5");
                }
                //if sophomore date in red is displayed
                if (sophomoreButton.Checked == true)
                    dateText.Text = ("Monday, April 3");
            }

            //if last name starts with P or Q and is freshman or sophomore, time is 8:30
            if (lastNameLetter >= 'P' && lastNameLetter <= 'Q' && (freshmanButton.Checked == true || sophomoreButton.Checked == true))
            {
                timeText.Text = ("8:30");

                //if freshman, date in red is displayed
                if (freshmanButton.Checked == true)
                {
                    dateText.Text = ("Tuesday, April 4");
                }
                //if sophomore date in red is displayed
                if (sophomoreButton.Checked == true)
                {
                    dateText.Text = ("Friday, March 31");
                }
            }

            //if last name starts with R or S and is freshamn or sophomore, time is 10
            if (lastNameLetter >= 'R' && lastNameLetter <= 'S' && (freshmanButton.Checked == true || sophomoreButton.Checked == true))
            {
                timeText.Text = ("10:00");

                //if freshman, date in red is displayed
                if (freshmanButton.Checked == true)
                {
                    dateText.Text = ("Tuesday, April 4");
                }
                //if sophomore date in red is displayed
                if (sophomoreButton.Checked == true)
                {
                    dateText.Text = ("Friday, March 31");
                }
            }

            //if last name starts with T or V and is frehsman or sophomore, time is 11:30
            if (lastNameLetter >= 'T' && lastNameLetter <= 'V' && (freshmanButton.Checked == true || sophomoreButton.Checked == true))
            {
                timeText.Text = ("11:30");

                //if freshman, date in red is displayed
                if (freshmanButton.Checked == true)
                {
                    dateText.Text = ("Tuesday, April 4");
                }
                //if sophomore date in red is displayed
                if (sophomoreButton.Checked == true)
                {
                    dateText.Text = ("Friday, March 31");
                }
            }

            //if last name starts with W or Z and is frehsman or sophomore, time is 2
            if (lastNameLetter >= 'W' && lastNameLetter <= 'Z' && (freshmanButton.Checked == true || sophomoreButton.Checked == true))
            {
                timeText.Text = ("2:00");

                //if freshman, date in red is displayed
                if (freshmanButton.Checked == true)
                {
                    dateText.Text = ("Tuesday, April 4");
                }
                //if sophomore date in red is displayed
                if (sophomoreButton.Checked == true)
                {
                    dateText.Text = ("Friday, March 31");
                }
            }

            //Junior and Senior section of code
            if (juniorButton.Checked || seniorButton.Checked)
                {
                    //if last name starts with T or Z and either junior or senior, time is 10:00
                    if (lastNameLetter >= 'T')
                    {
                        timeText.Text = ("10:00");
                    }
                    //if last name starts with P or S and either junior or senior, time is 8:30
                    else if (lastNameLetter >= 'P')
                    {
                        timeText.Text = ("8:30");
                    }
                    //if last name starts with J or O and either junior or senior, time is 4
                    else if (lastNameLetter >= 'J')
                    {
                        timeText.Text = ("4:00");
                    }
                    //if last name starts with E or I and either junior or senior, time is 2
                    else if (lastNameLetter >= 'E')
                    {
                        timeText.Text = ("2:00");
                    }

                    //if last name starts with A or B and either junior or senior, time is 11:30
                    else
                    {
                        timeText.Text = ("11:30");
                    }
                    //if junior, date in red is displayed
                    if (juniorButton.Checked)
                    {
                        dateText.Text = ("Thursday, March 30");
                    }
                    //if senior, date in red is displayed
                    if (seniorButton.Checked == true)
                    {
                        dateText.Text = ("Wednesday, March 29");
                    }
                }
            }
        

        //Clear Button
        private void clearButton_Click(object sender, EventArgs e)
        {
            lastNameText.Text = string.Empty;       //Empty last name textbox
            dateText.Text = string.Empty;           //Empty date label box
            timeText.Text = string.Empty;           //Empty time label box
        }
    }
}
    

