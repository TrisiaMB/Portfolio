﻿namespace Program_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customerDataTitle = new System.Windows.Forms.Label();
            this.wallMeasureLabel = new System.Windows.Forms.Label();
            this.paintCoatLabel = new System.Windows.Forms.Label();
            this.pricePerGalLabel = new System.Windows.Forms.Label();
            this.wallMeasureText = new System.Windows.Forms.TextBox();
            this.paintCoatText = new System.Windows.Forms.TextBox();
            this.pricePerGalText = new System.Windows.Forms.TextBox();
            this.generateQuoteButton = new System.Windows.Forms.Button();
            this.hoursOfLabor = new System.Windows.Forms.Label();
            this.gallonsNeeded = new System.Windows.Forms.Label();
            this.totalSqFt = new System.Windows.Forms.Label();
            this.hoursOfLaborLabel = new System.Windows.Forms.Label();
            this.gallonsNeededLabel = new System.Windows.Forms.Label();
            this.totalSqFtLabel = new System.Windows.Forms.Label();
            this.paintJobTotalTitle = new System.Windows.Forms.Label();
            this.paintCostLabel = new System.Windows.Forms.Label();
            this.laborCostLabel = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.totalCost = new System.Windows.Forms.Label();
            this.laborCost = new System.Windows.Forms.Label();
            this.paintCost = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // customerDataTitle
            // 
            this.customerDataTitle.AutoSize = true;
            this.customerDataTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerDataTitle.Location = new System.Drawing.Point(140, 9);
            this.customerDataTitle.Name = "customerDataTitle";
            this.customerDataTitle.Size = new System.Drawing.Size(110, 16);
            this.customerDataTitle.TabIndex = 0;
            this.customerDataTitle.Text = "Customer Data";
            // 
            // wallMeasureLabel
            // 
            this.wallMeasureLabel.AutoSize = true;
            this.wallMeasureLabel.Location = new System.Drawing.Point(46, 37);
            this.wallMeasureLabel.Name = "wallMeasureLabel";
            this.wallMeasureLabel.Size = new System.Drawing.Size(150, 13);
            this.wallMeasureLabel.TabIndex = 1;
            this.wallMeasureLabel.Text = "Wall Measurement (Sq. Feet): ";
            // 
            // paintCoatLabel
            // 
            this.paintCoatLabel.AutoSize = true;
            this.paintCoatLabel.Location = new System.Drawing.Point(113, 63);
            this.paintCoatLabel.Name = "paintCoatLabel";
            this.paintCoatLabel.Size = new System.Drawing.Size(76, 13);
            this.paintCoatLabel.TabIndex = 3;
            this.paintCoatLabel.Text = "Coats of Paint:";
            // 
            // pricePerGalLabel
            // 
            this.pricePerGalLabel.AutoSize = true;
            this.pricePerGalLabel.Location = new System.Drawing.Point(104, 89);
            this.pricePerGalLabel.Name = "pricePerGalLabel";
            this.pricePerGalLabel.Size = new System.Drawing.Size(85, 13);
            this.pricePerGalLabel.TabIndex = 5;
            this.pricePerGalLabel.Text = "Price per Gallon:";
            // 
            // wallMeasureText
            // 
            this.wallMeasureText.Location = new System.Drawing.Point(195, 34);
            this.wallMeasureText.Name = "wallMeasureText";
            this.wallMeasureText.Size = new System.Drawing.Size(100, 20);
            this.wallMeasureText.TabIndex = 2;
            this.wallMeasureText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // paintCoatText
            // 
            this.paintCoatText.Location = new System.Drawing.Point(195, 60);
            this.paintCoatText.Name = "paintCoatText";
            this.paintCoatText.Size = new System.Drawing.Size(100, 20);
            this.paintCoatText.TabIndex = 4;
            this.paintCoatText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pricePerGalText
            // 
            this.pricePerGalText.Location = new System.Drawing.Point(195, 89);
            this.pricePerGalText.Name = "pricePerGalText";
            this.pricePerGalText.Size = new System.Drawing.Size(100, 20);
            this.pricePerGalText.TabIndex = 6;
            this.pricePerGalText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // generateQuoteButton
            // 
            this.generateQuoteButton.Location = new System.Drawing.Point(144, 112);
            this.generateQuoteButton.Name = "generateQuoteButton";
            this.generateQuoteButton.Size = new System.Drawing.Size(102, 25);
            this.generateQuoteButton.TabIndex = 7;
            this.generateQuoteButton.Text = "Generate Quote";
            this.generateQuoteButton.UseVisualStyleBackColor = true;
            this.generateQuoteButton.Click += new System.EventHandler(this.generateQuoteButton_Click);
            // 
            // hoursOfLabor
            // 
            this.hoursOfLabor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hoursOfLabor.Location = new System.Drawing.Point(104, 247);
            this.hoursOfLabor.Name = "hoursOfLabor";
            this.hoursOfLabor.Size = new System.Drawing.Size(85, 20);
            this.hoursOfLabor.TabIndex = 14;
            // 
            // gallonsNeeded
            // 
            this.gallonsNeeded.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonsNeeded.Location = new System.Drawing.Point(104, 220);
            this.gallonsNeeded.Name = "gallonsNeeded";
            this.gallonsNeeded.Size = new System.Drawing.Size(85, 21);
            this.gallonsNeeded.TabIndex = 12;
            // 
            // totalSqFt
            // 
            this.totalSqFt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalSqFt.Location = new System.Drawing.Point(104, 194);
            this.totalSqFt.Name = "totalSqFt";
            this.totalSqFt.Size = new System.Drawing.Size(85, 20);
            this.totalSqFt.TabIndex = 10;
            // 
            // hoursOfLaborLabel
            // 
            this.hoursOfLaborLabel.AutoSize = true;
            this.hoursOfLaborLabel.Location = new System.Drawing.Point(18, 248);
            this.hoursOfLaborLabel.Name = "hoursOfLaborLabel";
            this.hoursOfLaborLabel.Size = new System.Drawing.Size(80, 13);
            this.hoursOfLaborLabel.TabIndex = 13;
            this.hoursOfLaborLabel.Text = "Hours of Labor:";
            // 
            // gallonsNeededLabel
            // 
            this.gallonsNeededLabel.AutoSize = true;
            this.gallonsNeededLabel.Location = new System.Drawing.Point(12, 221);
            this.gallonsNeededLabel.Name = "gallonsNeededLabel";
            this.gallonsNeededLabel.Size = new System.Drawing.Size(86, 13);
            this.gallonsNeededLabel.TabIndex = 11;
            this.gallonsNeededLabel.Text = "Gallons Needed:";
            // 
            // totalSqFtLabel
            // 
            this.totalSqFtLabel.AutoSize = true;
            this.totalSqFtLabel.Location = new System.Drawing.Point(3, 194);
            this.totalSqFtLabel.Name = "totalSqFtLabel";
            this.totalSqFtLabel.Size = new System.Drawing.Size(95, 13);
            this.totalSqFtLabel.TabIndex = 9;
            this.totalSqFtLabel.Text = "Total Square Feet:";
            // 
            // paintJobTotalTitle
            // 
            this.paintJobTotalTitle.AutoSize = true;
            this.paintJobTotalTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paintJobTotalTitle.Location = new System.Drawing.Point(135, 158);
            this.paintJobTotalTitle.Name = "paintJobTotalTitle";
            this.paintJobTotalTitle.Size = new System.Drawing.Size(121, 16);
            this.paintJobTotalTitle.TabIndex = 8;
            this.paintJobTotalTitle.Text = "Paint Job Totals";
            // 
            // paintCostLabel
            // 
            this.paintCostLabel.AutoSize = true;
            this.paintCostLabel.Location = new System.Drawing.Point(221, 194);
            this.paintCostLabel.Name = "paintCostLabel";
            this.paintCostLabel.Size = new System.Drawing.Size(58, 13);
            this.paintCostLabel.TabIndex = 15;
            this.paintCostLabel.Text = "Paint Cost:";
            // 
            // laborCostLabel
            // 
            this.laborCostLabel.AutoSize = true;
            this.laborCostLabel.Location = new System.Drawing.Point(218, 221);
            this.laborCostLabel.Name = "laborCostLabel";
            this.laborCostLabel.Size = new System.Drawing.Size(61, 13);
            this.laborCostLabel.TabIndex = 17;
            this.laborCostLabel.Text = "Labor Cost:";
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.AutoSize = true;
            this.totalCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalCostLabel.Location = new System.Drawing.Point(210, 248);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(69, 13);
            this.totalCostLabel.TabIndex = 19;
            this.totalCostLabel.Text = "Total Cost:";
            // 
            // totalCost
            // 
            this.totalCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCost.Location = new System.Drawing.Point(285, 247);
            this.totalCost.Name = "totalCost";
            this.totalCost.Size = new System.Drawing.Size(88, 20);
            this.totalCost.TabIndex = 20;
            // 
            // laborCost
            // 
            this.laborCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborCost.Location = new System.Drawing.Point(285, 220);
            this.laborCost.Name = "laborCost";
            this.laborCost.Size = new System.Drawing.Size(88, 20);
            this.laborCost.TabIndex = 18;
            // 
            // paintCost
            // 
            this.paintCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paintCost.Location = new System.Drawing.Point(285, 193);
            this.paintCost.Name = "paintCost";
            this.paintCost.Size = new System.Drawing.Size(88, 20);
            this.paintCost.TabIndex = 16;
            // 
            // Form1
            // 
            this.AcceptButton = this.generateQuoteButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(390, 300);
            this.Controls.Add(this.paintCost);
            this.Controls.Add(this.laborCost);
            this.Controls.Add(this.totalCost);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.laborCostLabel);
            this.Controls.Add(this.paintCostLabel);
            this.Controls.Add(this.paintJobTotalTitle);
            this.Controls.Add(this.totalSqFtLabel);
            this.Controls.Add(this.gallonsNeededLabel);
            this.Controls.Add(this.hoursOfLaborLabel);
            this.Controls.Add(this.totalSqFt);
            this.Controls.Add(this.gallonsNeeded);
            this.Controls.Add(this.hoursOfLabor);
            this.Controls.Add(this.generateQuoteButton);
            this.Controls.Add(this.pricePerGalText);
            this.Controls.Add(this.paintCoatText);
            this.Controls.Add(this.wallMeasureText);
            this.Controls.Add(this.pricePerGalLabel);
            this.Controls.Add(this.paintCoatLabel);
            this.Controls.Add(this.wallMeasureLabel);
            this.Controls.Add(this.customerDataTitle);
            this.Name = "Form1";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label customerDataTitle;
        private System.Windows.Forms.Label wallMeasureLabel;
        private System.Windows.Forms.Label paintCoatLabel;
        private System.Windows.Forms.Label pricePerGalLabel;
        private System.Windows.Forms.TextBox wallMeasureText;
        private System.Windows.Forms.TextBox paintCoatText;
        private System.Windows.Forms.TextBox pricePerGalText;
        private System.Windows.Forms.Button generateQuoteButton;
        private System.Windows.Forms.Label hoursOfLabor;
        private System.Windows.Forms.Label gallonsNeeded;
        private System.Windows.Forms.Label totalSqFt;
        private System.Windows.Forms.Label hoursOfLaborLabel;
        private System.Windows.Forms.Label gallonsNeededLabel;
        private System.Windows.Forms.Label totalSqFtLabel;
        private System.Windows.Forms.Label paintJobTotalTitle;
        private System.Windows.Forms.Label paintCostLabel;
        private System.Windows.Forms.Label laborCostLabel;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label totalCost;
        private System.Windows.Forms.Label laborCost;
        private System.Windows.Forms.Label paintCost;
    }
}

