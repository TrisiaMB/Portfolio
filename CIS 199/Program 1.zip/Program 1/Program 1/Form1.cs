﻿//B9279
//Program 1
//CIS 199-02-4172
//This program takes customer inputs such as wall measurement, coats of paint, and price per gallon.
//They can then generate their quote for paint job totals by pressing the button and get outputs 
//according to their previous inputs.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void generateQuoteButton_Click(object sender, EventArgs e)
        {
            float TOTAL_SQ_FT;               //Toltal square feet calculated    
            float GALLONS;                  //Total gallons calculated
            float LABOR_HOURS;              //Hours of labor calculated
            float PAINT_COST;               //Cost of paint calculated    
            float LABOR_COST;               //Cost of labor calculated
            float TOTAL_COST;               //Total cost of paint job calculated
            
                
                var wallMeasurement = float.Parse(wallMeasureText.Text);        //Wall measurement comes from input
                var coatsOfPaint = int.Parse(paintCoatText.Text);               //Paint coat comes from input
                var pricePerGallon = float.Parse(pricePerGalText.Text);         //Price per gallon comes from input

            decimal SQUARE_FEET_RATE = 330m;              //Shows that 330 square feet of wall space can be covered for 6hrs
            decimal LABOR_HOUR_RATE = 6m;                 //6 hours of labor for 330 square feet
            decimal LABOR_COST_RATE = 10.50M;             // Cost of 1hr of labor is 10.50

            
            TOTAL_SQ_FT = coatsOfPaint* wallMeasurement;                     //Calculate total square feet needed to be painted and changed decimal to float 
            totalSqFt.Text = TOTAL_SQ_FT.ToString("n1");                      //Display total square feet next to "Total Square Feet" label  


            GALLONS = TOTAL_SQ_FT / (float) SQUARE_FEET_RATE;                   //Calculate gallons of paint needed, changed deicimal to float 
            gallonsNeeded.Text = Math.Ceiling(GALLONS).ToString("n0");       //Display gallons of paint needed next to "Gallons Needed" label


            LABOR_HOURS = GALLONS * (float) LABOR_HOUR_RATE;                   //Calculate labor hour, changed decimal to float
            hoursOfLabor.Text = LABOR_HOURS.ToString("n1");                  //Display gallons of paint needed next to "Hours of labor" label

            PAINT_COST = float.Parse(gallonsNeeded.Text) * pricePerGallon;   //Calculate paint cost
            paintCost.Text = PAINT_COST.ToString("C");                       //Display paint cost needed next to "Paint Cost" label

            LABOR_COST = LABOR_HOURS * (float) LABOR_COST_RATE;                 //Caluclate labor cost, changed decimal to float
            laborCost.Text = LABOR_COST.ToString("C");                       //Display labor cost next to "Labor Cost" label

            TOTAL_COST = PAINT_COST + LABOR_COST;                              //Calculate labor cost
            totalCost.Text = TOTAL_COST.ToString("C");                       //Display total cost next to "Total Cost" Label
        

                            
          















        }
    }
}
