﻿//B9279
//Program 1
//CIS 199-02-4172
//This program takes customer inputs such as wall measurement, coats of paint, and price per gallon.
//They can then generate their quote for paint job totals by pressing the button and get outputs according to their previous inputs.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void generateQuoteButton_Click(object sender, EventArgs e)
        {
            float WALLMEASUREMENT;           //Wall Measurement 
            int COATSOFPAINT;                //Coats of paint
            float PRICEPERGALLON;            //Price per Gallon
            float TOTALSQFT;                 //Toltal Square Feet
            float GALLONS;                  
            float LABORHOURS;              //Hours of Labor
            float PAINTCOST;               //CostofPaint
            float LABORCOST;               //Cost of Labor
            float TOTALCOST;               //Total cost of paint job
            
                
                WALLMEASUREMENT = float.Parse(wallMeasureText.Text);        //Wall measurement comes from input
                COATSOFPAINT = int.Parse(paintCoatText.Text);               //Paint coat comes from input
                PRICEPERGALLON = float.Parse(pricePerGalText.Text);         //Price per gallon comes from input

            decimal SQUAREFEETRATE = 330m;                                  //Shows that 330 square feet of wall space can be covered for 6hrs
            decimal LABORHOURRATE = 6m;                                     //6 hours of labor for 330 square feet
            decimal LABORCOSTRATE = 10.50M;                                 // Cost of 1hr of labor is 10.50

            
            TOTALSQFT = COATSOFPAINT * WALLMEASUREMENT;                     //Calculate total square feet needed to be painted and changed decimal to float 
            totalSqFt.Text = TOTALSQFT.ToString("n1");                      //Display total square feet next to "Total Square Feet" label  


            GALLONS = TOTALSQFT / (float) SQUAREFEETRATE;                   //Calculate gallons of paint needed, changed deicimal to float 
            gallonsNeeded.Text = Math.Ceiling(GALLONS).ToString("N");       //Display gallons of paint needed next to "Gallons Needed" label


            LABORHOURS = GALLONS * (float) LABORHOURRATE;                   //Calculate labor hour, changed decimal to float
            hoursOfLabor.Text = LABORHOURS.ToString("n1");                  //Display gallons of paint needed next to "Hours of labor" label

            PAINTCOST = float.Parse(gallonsNeeded.Text) * PRICEPERGALLON;   //Calculate paint cost
            paintCost.Text = PAINTCOST.ToString("C");                       //Display paint cost needed next to "Paint Cost" label

            LABORCOST = LABORHOURS * (float) LABORCOSTRATE;                 //Caluclate labor cost, changed decimal to float
            laborCost.Text = LABORCOST.ToString("C");                       //Display labor cost next to "Labor Cost" label

            TOTALCOST = PAINTCOST + LABORCOST;                              //Calculate labor cost
            totalCost.Text = TOTALCOST.ToString("c");                       //Display total cost next to "Total Cost" Label
        

                            
          















        }
    }
}
