﻿namespace Program4
{
    partial class PackageData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.packageTitleLabel = new System.Windows.Forms.Label();
            this.originZipLabel = new System.Windows.Forms.Label();
            this.destinationZLabel = new System.Windows.Forms.Label();
            this.lengthLabel = new System.Windows.Forms.Label();
            this.widthLabel = new System.Windows.Forms.Label();
            this.heightLabel = new System.Windows.Forms.Label();
            this.weightLabel = new System.Windows.Forms.Label();
            this.destinationZText = new System.Windows.Forms.TextBox();
            this.heightText = new System.Windows.Forms.TextBox();
            this.widthText = new System.Windows.Forms.TextBox();
            this.lengthText = new System.Windows.Forms.TextBox();
            this.originZipText = new System.Windows.Forms.TextBox();
            this.weightText = new System.Windows.Forms.TextBox();
            this.addButton = new System.Windows.Forms.Button();
            this.pricesList = new System.Windows.Forms.ListBox();
            this.detailsButton = new System.Windows.Forms.Button();
            this.sendToButton = new System.Windows.Forms.Button();
            this.sendFromButton = new System.Windows.Forms.Button();
            this.pricesTitleLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // packageTitleLabel
            // 
            this.packageTitleLabel.AutoSize = true;
            this.packageTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.packageTitleLabel.Location = new System.Drawing.Point(76, 20);
            this.packageTitleLabel.Name = "packageTitleLabel";
            this.packageTitleLabel.Size = new System.Drawing.Size(129, 16);
            this.packageTitleLabel.TabIndex = 0;
            this.packageTitleLabel.Text = "Enter Package Data";
            // 
            // originZipLabel
            // 
            this.originZipLabel.AutoSize = true;
            this.originZipLabel.Location = new System.Drawing.Point(38, 66);
            this.originZipLabel.Name = "originZipLabel";
            this.originZipLabel.Size = new System.Drawing.Size(83, 13);
            this.originZipLabel.TabIndex = 1;
            this.originZipLabel.Text = "Origin Zip Code:";
            // 
            // destinationZLabel
            // 
            this.destinationZLabel.AutoSize = true;
            this.destinationZLabel.Location = new System.Drawing.Point(12, 92);
            this.destinationZLabel.Name = "destinationZLabel";
            this.destinationZLabel.Size = new System.Drawing.Size(109, 13);
            this.destinationZLabel.TabIndex = 3;
            this.destinationZLabel.Text = "Destination Zip Code:";
            // 
            // lengthLabel
            // 
            this.lengthLabel.AutoSize = true;
            this.lengthLabel.Location = new System.Drawing.Point(32, 118);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(89, 13);
            this.lengthLabel.TabIndex = 5;
            this.lengthLabel.Text = "Package Length:";
            // 
            // widthLabel
            // 
            this.widthLabel.AutoSize = true;
            this.widthLabel.Location = new System.Drawing.Point(37, 144);
            this.widthLabel.Name = "widthLabel";
            this.widthLabel.Size = new System.Drawing.Size(84, 13);
            this.widthLabel.TabIndex = 7;
            this.widthLabel.Text = "Package Width:";
            // 
            // heightLabel
            // 
            this.heightLabel.AutoSize = true;
            this.heightLabel.Location = new System.Drawing.Point(34, 170);
            this.heightLabel.Name = "heightLabel";
            this.heightLabel.Size = new System.Drawing.Size(87, 13);
            this.heightLabel.TabIndex = 9;
            this.heightLabel.Text = "Package Height:";
            // 
            // weightLabel
            // 
            this.weightLabel.AutoSize = true;
            this.weightLabel.Location = new System.Drawing.Point(12, 196);
            this.weightLabel.Name = "weightLabel";
            this.weightLabel.Size = new System.Drawing.Size(112, 13);
            this.weightLabel.TabIndex = 11;
            this.weightLabel.Text = "Package Weight (lbs):";
            // 
            // destinationZText
            // 
            this.destinationZText.Location = new System.Drawing.Point(127, 89);
            this.destinationZText.Name = "destinationZText";
            this.destinationZText.Size = new System.Drawing.Size(100, 20);
            this.destinationZText.TabIndex = 4;
            // 
            // heightText
            // 
            this.heightText.Location = new System.Drawing.Point(127, 167);
            this.heightText.Name = "heightText";
            this.heightText.Size = new System.Drawing.Size(100, 20);
            this.heightText.TabIndex = 10;
            // 
            // widthText
            // 
            this.widthText.Location = new System.Drawing.Point(127, 141);
            this.widthText.Name = "widthText";
            this.widthText.Size = new System.Drawing.Size(100, 20);
            this.widthText.TabIndex = 8;
            // 
            // lengthText
            // 
            this.lengthText.Location = new System.Drawing.Point(127, 115);
            this.lengthText.Name = "lengthText";
            this.lengthText.Size = new System.Drawing.Size(100, 20);
            this.lengthText.TabIndex = 6;
            // 
            // originZipText
            // 
            this.originZipText.Location = new System.Drawing.Point(127, 63);
            this.originZipText.Name = "originZipText";
            this.originZipText.Size = new System.Drawing.Size(100, 20);
            this.originZipText.TabIndex = 2;
            // 
            // weightText
            // 
            this.weightText.Location = new System.Drawing.Point(127, 193);
            this.weightText.Name = "weightText";
            this.weightText.Size = new System.Drawing.Size(100, 20);
            this.weightText.TabIndex = 12;
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(127, 219);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(100, 23);
            this.addButton.TabIndex = 13;
            this.addButton.Text = "Add Package";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // pricesList
            // 
            this.pricesList.FormattingEnabled = true;
            this.pricesList.Location = new System.Drawing.Point(248, 58);
            this.pricesList.Name = "pricesList";
            this.pricesList.Size = new System.Drawing.Size(170, 173);
            this.pricesList.TabIndex = 15;
            this.pricesList.SelectedIndexChanged += new System.EventHandler(this.pricesList_SelectedIndexChanged);
            // 
            // detailsButton
            // 
            this.detailsButton.Location = new System.Drawing.Point(427, 56);
            this.detailsButton.Name = "detailsButton";
            this.detailsButton.Size = new System.Drawing.Size(89, 23);
            this.detailsButton.TabIndex = 16;
            this.detailsButton.Text = "Details";
            this.detailsButton.UseVisualStyleBackColor = true;
            this.detailsButton.Click += new System.EventHandler(this.detailsButton_Click);
            // 
            // sendToButton
            // 
            this.sendToButton.Location = new System.Drawing.Point(427, 208);
            this.sendToButton.Name = "sendToButton";
            this.sendToButton.Size = new System.Drawing.Size(89, 23);
            this.sendToButton.TabIndex = 18;
            this.sendToButton.Text = "Send to UofL";
            this.sendToButton.UseVisualStyleBackColor = true;
            this.sendToButton.Click += new System.EventHandler(this.sendToButton_Click);
            // 
            // sendFromButton
            // 
            this.sendFromButton.Location = new System.Drawing.Point(427, 134);
            this.sendFromButton.Name = "sendFromButton";
            this.sendFromButton.Size = new System.Drawing.Size(89, 23);
            this.sendFromButton.TabIndex = 17;
            this.sendFromButton.Text = "Send from Uofl";
            this.sendFromButton.UseVisualStyleBackColor = true;
            this.sendFromButton.Click += new System.EventHandler(this.sendFromButton_Click);
            // 
            // pricesTitleLabel
            // 
            this.pricesTitleLabel.AutoSize = true;
            this.pricesTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricesTitleLabel.Location = new System.Drawing.Point(278, 20);
            this.pricesTitleLabel.Name = "pricesTitleLabel";
            this.pricesTitleLabel.Size = new System.Drawing.Size(104, 16);
            this.pricesTitleLabel.TabIndex = 14;
            this.pricesTitleLabel.Text = "Package Prices";
            // 
            // PackageData
            // 
            this.AcceptButton = this.addButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 261);
            this.Controls.Add(this.pricesTitleLabel);
            this.Controls.Add(this.sendFromButton);
            this.Controls.Add(this.sendToButton);
            this.Controls.Add(this.detailsButton);
            this.Controls.Add(this.pricesList);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.weightText);
            this.Controls.Add(this.originZipText);
            this.Controls.Add(this.lengthText);
            this.Controls.Add(this.widthText);
            this.Controls.Add(this.heightText);
            this.Controls.Add(this.destinationZText);
            this.Controls.Add(this.weightLabel);
            this.Controls.Add(this.heightLabel);
            this.Controls.Add(this.widthLabel);
            this.Controls.Add(this.lengthLabel);
            this.Controls.Add(this.destinationZLabel);
            this.Controls.Add(this.originZipLabel);
            this.Controls.Add(this.packageTitleLabel);
            this.Name = "PackageData";
            this.Text = "Program 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label packageTitleLabel;
        private System.Windows.Forms.Label originZipLabel;
        private System.Windows.Forms.Label destinationZLabel;
        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.Label widthLabel;
        private System.Windows.Forms.Label heightLabel;
        private System.Windows.Forms.Label weightLabel;
        private System.Windows.Forms.TextBox destinationZText;
        private System.Windows.Forms.TextBox heightText;
        private System.Windows.Forms.TextBox widthText;
        private System.Windows.Forms.TextBox lengthText;
        private System.Windows.Forms.TextBox originZipText;
        private System.Windows.Forms.TextBox weightText;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.ListBox pricesList;
        private System.Windows.Forms.Button detailsButton;
        private System.Windows.Forms.Button sendToButton;
        private System.Windows.Forms.Button sendFromButton;
        private System.Windows.Forms.Label pricesTitleLabel;
    }
}

