﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    public class GroundPackage
    {
        //Backing fields
        public int _zipOrigin;
        public int _zipDestination;
        public double _length;
        public double _width;
        public double _height;
        public double _weight;

        //constructor
        public GroundPackage(int zOrigin, int zDestination, double l, double w, double h, double weight)
        {
            OriginZip = zOrigin;
            DestinationZip = zDestination;
            Length = l;
            Width = w;
            Height = h;
            Weight = weight;
        }

        //Zip origin property
        public int OriginZip
        {
            //pre condition: none
            //Post condition: zip origin is returned
            get
            {
                return _zipOrigin;
            }
            //pre condition: value is between 00000 and 99999
            //post condition: if pre condition is followed, zip code is set. Otherwise 40202
            set
            {
                if (value >= 00000 && value <= 99999 && value.ToString().Length == 5)
                    _zipOrigin = value;
                else
                    _zipOrigin = 40202;
            }
        }

        //Zip Destination property
        public int DestinationZip
        {
            //pre condition: none
            //post condition: zip destination is returned
            get
            {
                return _zipDestination;
            }
            set
            {
                //pre condition: value is between 00000 and 99999
                //post condition: if pre condition is followed, zip is set. Otherwise 90210
                if (value >= 00000 && value <= 99999 && value.ToString().Length == 5)
                    _zipDestination = value;
                else
                    _zipDestination = 90210;
            }
        }

        //Length property
        public double Length
        {
            //pre condition: none
            //post condition: length is returned
            get
            {
                return _length;
            }
            //pre condition: length has to be greater than 0
            //post condition: length is set, otherwise legnth is 1.0
            set
            {
                if (value > 0)
                    _length = value;
                else
                    _length = 1.0;
            }
        }

        //Width property
        public double Width
        {
            //pre condition: none
            //post condition: width is returned
            get
            {
                return _width;
            }
            //pre condition: width has to be greater than 0
            //post condition: width is set, otherwise width is 1.0
            set
            {
                if (value > 0)
                    _width = value;
                else
                    _width = 1.0;
            }
        }

        //Height property
        public double Height
        {
            //pre condition: none
            //post condition: height is returned
            get
            {
                return _height;
            }
            //pre condition: height has to be greater than 0
            //post condition: height is set, otherwise height is 1.0
            set
            {
                if (value > 0)
                    _height = value;
                else
                    _height = 1.0;
            }
        }

        //Weight property
        public double Weight
        {
            //pre condition: none
            //post condition: Weight is returned
            get
            {
                return _weight;
            }
            //pre condition: Weight has to be greater than 0
            //post condition: Weight is set, otherwise weight is 1.0
            set
            {
                if (value > 0)
                    _weight = value;
                else
                    _weight = 1.0;
            }
        }

        //Zone distance property
        public int ZoneDistance
        {
            //pre condition: zip origin and destination havev to have data
            //post condition: the positive difference between the zip codes is returned
            get
            {
                int zipO = OriginZip / 10000;
                int zipD = DestinationZip / 10000;
                return Math.Abs(zipO - zipD);
            }
        }

        //CalcCost method
        public double CalcCost()
        {
            //pre condition: length, width, height, weight and zone distance must have valid data
            //post condition: returns the cost 
            
           double costMultiple = 0.20;
           double distanceMultiple = 0.50;

          double cost = costMultiple * (Length + Width + Height) + distanceMultiple * (ZoneDistance + 1) * (Weight);
            return cost;
        }

        //Override 
        public override string ToString()
        {
            //returns string of data, each in a seperate line
            return "Zip Code Origin: " + OriginZip.ToString() + System.Environment.NewLine +
                "Zip Code Destination: " + DestinationZip.ToString() + System.Environment.NewLine +
                "Zone Distance: " + ZoneDistance.ToString() + System.Environment.NewLine +
                "Length: " + Length.ToString() + System.Environment.NewLine +
                "Width: " + Width.ToString() + System.Environment.NewLine +
                "Height: " + Height.ToString() + System.Environment.NewLine +
                "Weight: " + Weight.ToString() + System.Environment.NewLine;
        }
    }
}
