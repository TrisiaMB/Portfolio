﻿//B9279
//Program 4
//Due: April 25
//CIS 199-02
//This program calculates the cost of the package based on user input.
//It also updates origin and destination zip codes based on button clicked and 
//updates price on the list box if changes are made.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program4
{
    public partial class PackageData : Form
    {
        //field
        private List<GroundPackage> theGroundPackage = new List<GroundPackage>();

        public PackageData()
        {
            InitializeComponent();
        }

        //PreCondition: None
        //PostCondition: data cannot be empty and if it is messagebox will show user error. If all is valid
        //then true is returned. Otherwise false is returned.
        //Method to validate package inputs through the use of if and else statements to make sure userinput is valid.
        private bool ValidatePackage(out int oZip, out int dZip, out double length, out double width, out double height, out double weight)
        {
            bool isValid = false;

            //default values
            oZip = 0;
            dZip = 0;
            length = 0;
            width = 0;
            height = 0;
            weight = 0;

            if (int.TryParse(originZipText.Text, out oZip))
            {
                if (int.TryParse(destinationZText.Text, out dZip))
                {
                    if (double.TryParse(lengthText.Text, out length))
                    {
                        if (double.TryParse(widthText.Text, out width))
                        {
                            if (double.TryParse(heightText.Text, out height))
                            {
                                if (double.TryParse(weightText.Text, out weight))
                                {
                                    isValid = true;
                                }
                                else
                                    MessageBox.Show("Please enter package weight.");
                            }
                            else
                                MessageBox.Show("Please enter package height.");
                        }
                        else
                            MessageBox.Show("Please enter package width.");
                    }
                    else
                        MessageBox.Show("Please enter package length.");
                }
                else
                    MessageBox.Show("Please enter the destination zip code.");
            }
            else
                MessageBox.Show("Please enter the origin zip code.");

            return isValid;
        }

        //PreCondition: Add button is clicked.
        //PostCondition: if all is valide, package is added onto list
        private void addButton_Click(object sender, EventArgs e)
        {
            //holds package data
            GroundPackage myPackage;

            int originZ;
            int destinationZ;
            double pLength;
            double pWidth;
            double pHeight;
            double pWeight;

            //only if input is valid
            if (ValidatePackage(out originZ, out destinationZ, out pLength, out pWidth, out pHeight, out pWeight))
            {
                //retrieves properties from class 
                myPackage = new GroundPackage(originZ, destinationZ, pLength, pWidth, pHeight, pWeight);

                //Adds my package to theGroundPackage list
                theGroundPackage.Add(myPackage);
                //gets calcost method from class
                double thecost = myPackage.CalcCost();
                //adds the method to pricelist box
                pricesList.Items.Add(thecost.ToString("C"));

                //clears textboxes
                originZipText.Clear();
                destinationZText.Clear();
                lengthText.Clear();
                widthText.Clear();
                heightText.Clear();
                weightText.Clear();
            }

        }
        //PreCondition: Item must be in listbox
        //PostCondition: Item is selected 
        private void pricesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index;

            index = pricesList.SelectedIndex;
        }

        //PreCondition: Item has to be in list box
        //Post Condition: Displays a message box with package information
        private void detailsButton_Click(object sender, EventArgs e)
        {
            //gets selected index
            int index;
            index = pricesList.SelectedIndex;

            //if an item is selected froom index, show tostring from class
            if (index >= 0)
                MessageBox.Show(theGroundPackage[index].ToString());
           
            //if user does not select anything, show error message
            else
            {
                MessageBox.Show("Please select a package.");
            }
        }
                
                
        //PreCondition: Item has to be in list box
        //PostCondition: Displays a message box with package information but origin zip is 40202
        //                  and new price is updated on list box
        private void sendFromButton_Click(object sender, EventArgs e)
        {
            //gets selected index
            int index;
            index = pricesList.SelectedIndex;

            //If a package is selected
            if (index >= 0)
            {
                //origin zip is 40292
                //retrieve and replace origin zip from calc cost to get new price
                //and show message box that zip code has been updated
                theGroundPackage[index].OriginZip = 40292;
                pricesList.Items[index] = theGroundPackage[index].CalcCost().ToString("c");
                MessageBox.Show("Origin zip code has been updated");
            }
            //if user does not select a package, display error message
            else
            {
                MessageBox.Show("Please select a package.");

            }
        }

        //PreCondition: Item has to be in list box
        //PostCondition: Displays a message boxc with package information but destinatio zip is 90210
        //              and new price is updated on list box
        private void sendToButton_Click(object sender, EventArgs e)
        {
            //get selected index
            int index;
            index = pricesList.SelectedIndex;

            if(index >=0)
            {
                //destination zip is changed to 40292
                //retrieve and replace origin zip from calc cost to get new price
                //and show message box that zip code has been updated
                theGroundPackage[index].DestinationZip = 40292;
                pricesList.Items[index] = theGroundPackage[index].CalcCost().ToString("c");
                MessageBox.Show("Destination zip code has been updated.");
            }
            else
            {
                //if user does not select a package, display error message
                MessageBox.Show("Please select a package.");
            }
            }
        }
    }

        
         
    



