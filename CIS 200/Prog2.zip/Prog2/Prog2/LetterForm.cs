﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class LetterForm : Form
    {
        //list of addresses
        private List<Address> addressList;

        public LetterForm()
        {
            InitializeComponent();
            
        }

        //Combo boxes populated when load event is fired
        private void LetterForm_Load(object sender, EventArgs e)
        {
            //for each address in adresslist, present address using name

            foreach(Address adress in addressList)
            {
                oAddressCombo.Items.Add(adress.Name);
                DAddressCombo.Items.Add(adress.Name);
            }
        }

        //Precondition: Ok button is clicked
        //Postcondition: Parcel added onto report
        private void OkButton_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        //Precondition: Cancel button is clicked
        //Postcondition: Application is closed
        private void cancelButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public string OAddress
        {
            get
            {
                //Precondition: combobox is selected
                //Postcondition: selected item is returned
                return oAddressCombo.SelectedItem.ToString();
            }

            set
            {
                // Precondition:  None
            // Postcondition: origin address is set to specified value
                oAddressCombo.SelectedItem = value;
            }
        }

        public string DAddress
        {
            get
            {
                //Precondition: combobox is selected
                //Postcondition: selected item is returned
                return DAddressCombo.SelectedItem.ToString();
            }

            set
            {
                // Precondition:  None
                // Postcondition: destination address is set to specified value
                DAddressCombo.SelectedItem = value;
            }
        }

        public string FixedCost
        {
            get
            {
                //Precondition: None
            // Postcondition: The text of form's name field is returned
                return fixedCost.Text;
            }
            set
            {
                // Precondition:  None
                // Postcondition: fixed cost is set to specified value
                fixedCost.Text = value;
            }
        }

        //Precondition: Attempt to change focus from fixedcost
        //Postcondition: If entered value is valid, focus will change, else focus will remain and error provider message set
        private void fixedCost_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(fixedCost.Text))
            {
                // Stops focus from changing process, will not proceed to validated event
                e.Cancel = true;

                //set error message
                errorProvider1.SetError(fixedCost, "Enter city!");

                //Selects inputed text
                fixedCost.SelectAll();
            }

        }
        //Precondition: Zip validating sucess
        //Post condition: Error message is cleared
        private void fixedCost_Validated(object sender, EventArgs e)
        {
            //Clears error message
            errorProvider1.SetError(fixedCost, "");
        }

    }
}