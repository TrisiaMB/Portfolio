﻿//C7032
//CIS-200-01-4178
//Program 2
//Due: 10/23/17
using Prog2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        //Userparcelview
        private UserParcelView upv;

        public Prog2Form()
        {

            InitializeComponent();
            upv = new UserParcelView();
        
            //Test Data
            upv.AddAddress("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 40202);                           //Test Address 1
            upv.AddAddress("Jane Doe", "987 Main St.", "",
               "Beverly Hills", "CA", 90210);                                   //Test Address 2
            upv.AddAddress("James Kirk", "654 Roddenberry Way", "Suite 321",
               "El Paso", "TX", 79901);                                         //Test Address3
            upv.AddAddress("John Crichton", "678 Pau Place", "Apt. 7",
               "Portland", "ME", 04101);                                        //Test Address 4
            upv.AddAddress("Donald Duck", "1313 Webfoot Walk", "Apartment 13",
                "Duckburg", "KY", 40204);                                       //Test Address 5
            upv.AddAddress("Sherlock Holmes", "221B Baker Street", "Apartment 2",
                "London", "OH", 43002);                                         //Test Address 6
            upv.AddAddress("Spongebob Squarepants", "124 Conch Street", "Apartment 3",
                "Bikini Bottom", "FL", 32003);                                  //Test Address 7
            upv.AddAddress("Peter Griffin", "31 Spooner Street", "Apartment 2",
                "Quohog", "NY", 10001);                                         //Test Address 8

            //Add letters
            upv.AddLetter(upv.AddressAt(0), upv.AddressAt(1), 3.5M);
            upv.AddLetter(upv.AddressAt(2), upv.AddressAt(3), 5.5M);

            //Add ground package
            upv.AddGroundPackage(upv.AddressAt(4), upv.AddressAt(5), 2, 4, 6, 3);
            upv.AddGroundPackage(upv.AddressAt(6), upv.AddressAt(7), 1, 3, 5, 2);

            //Add next day air package
            upv.AddNextDayAirPackage(upv.AddressAt(1), upv.AddressAt(2), 3, 4, 5, 1, 10.0M);
            upv.AddNextDayAirPackage(upv.AddressAt(3), upv.AddressAt(4), 4, 5, 6, 3, 3.99M);

            //Add Two day air package
            upv.AddTwoDayAirPackage(upv.AddressAt(5), upv.AddressAt(6), 1, 2, 3, 4, TwoDayAirPackage.Delivery.Early);
            upv.AddTwoDayAirPackage(upv.AddressAt(0), upv.AddressAt(7), 4, 3, 2, 1, TwoDayAirPackage.Delivery.Saver);
        }
        
        //Precondition: File > about is clicked
        //Postcondition: Messagebox appears with information
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NL = Environment.NewLine;
            MessageBox.Show($"C7032{NL}CIS-200-01-4178{NL}Program 2{NL}Due: 10/23/17");
        }

        //Precondition: File> exit is clicked
        //Postcondition: User is exited from application
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Precondition:Report>list Address is clicked
        //Postcondition: List of addresses is returned
        private void listAddressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // New line shortcut
            string NL = Environment.NewLine;

            //builds string
            StringBuilder result = new StringBuilder();

            //For each address in address list, add onto textbox
            foreach (Address address in upv.AddressList)
            {
                result.Append("---------------------------");
                result.Append(NL);
                result.Append(address.ToString());
                result.Append(NL);
            }
            //place restults in text box
            listTextBox.Text = result.ToString();
        }

        //Precondition: Report> List parcels is clicked
        //Postcodition: A list of parcels is returned 
        private void listReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //New line shortcut
            string NL = Environment.NewLine;

            //builds string
            StringBuilder result = new StringBuilder();

            //For each parcel in parcel list, add onto textbox
            foreach (Parcel parcel in upv.ParcelList)
            {
                result.Append("---------------------------");
                result.Append(NL);
                result.Append(parcel.ToString());
                result.Append(NL);
            }
            //place results in text box
            listTextBox.Text = result.ToString();
        }

        //Precondition: Insert> Address is clicked
        //Postcondition: AddressForm appears
        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result;
            Prog2.AddressForm address = new Prog2.AddressForm();
          result= address.ShowDialog();
             

            if(result ==DialogResult.OK)
            {
                
                Address addresses = new Address(address.AddressName, address.Address1,
                        address.Address2, address.City, address.State, int.Parse(address.Zip));
                       
                upv.AddressList.Add(addresses);
            }
            
        }

        //Precondition: Insert>Letter is clicked
        //Postcondition: LetterForm appears
        private void letterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result;
            
            Prog2.LetterForm letter = new LetterForm();
           result= letter.ShowDialog();
            
            

            if(result == DialogResult.OK)
            {
                
            }
        }
    }
}
