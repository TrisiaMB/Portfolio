﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class AddressForm : Form
    {
        public AddressForm()
        {
            InitializeComponent();

        }
        public string AddressName
        {
            // Precondition:  None
            // Postcondition: The text of form's name field is returned
            get
            {
                return nameTxt.Text;
            }
            // Precondition:  None
            // Postcondition: The text of form's name field is set to specified value
            set
            {
                nameTxt.Text = value.Trim();
            }
        }

        public string Address1
        {
            // Precondition:  None
            // Postcondition: The text of form's address field is returned
            get
            {
                return address1txt.Text;
            }
            // Precondition:  None
            // Postcondition: The text of form's address1 field is set to specified value
            set
            {
                address1txt.Text = value.Trim();
            }
        }

        public string Address2
        {
            get
            // Precondition:  None
            // Postcondition: The text of form's address field is returned
            {
                return address2txt.Text;
            }
            // Precondition:  None
            // Postcondition: The text of form's address2 field is set to specified value
            set
            {
                address2txt.Text = value.Trim();
            }
        }

        public string City
        {
            get
            // Precondition:  None
            // Postcondition: The text of form's city field is returned
            {
                return cityTxt.Text;
            }
            // Precondition:  None
            // Postcondition: The text of form's city field is set to specified value
            set
            {
                cityTxt.Text = value.Trim();
            }
        }

        public string State
        {
            get
            {
                return stateCombo.SelectedItem.ToString();
            }

            set
            {
                stateCombo.SelectedItem = value;
            }
        }

        public string Zip
        {
            get
            // Precondition:  None
            // Postcondition: The text of form's zip field is returned
            {
                return zipTxt.Text;
            }
            // Precondition:  None
            // Postcondition: The text of form's zip field is set to specified value
            set
            {
                zipTxt.Text = value.Trim();
            }
        }


        //Precondition: OK button is clicked
        //Postcondition: If all controls on form validate,input box is dismissed with Ok result
        private void okButton_Click(object sender, EventArgs e)
        {
            // Raise validating event for all enabled controls on form
            // If all pass, ValidateChildren() will be true
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        //Precondition: Cancel button is clicked
        //Postcondition: Application is closed
        private void cancelButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Precondition: Attempt to change focus from ziptxt
        //Postcondition: If entered value is valid, focus will change, else focus will remain and error provider message set
        private void zipTxt_Validating(object sender, CancelEventArgs e)
        {
            //Min and Max zips
            int minZip = 00000;
            int maxZip = 99999;
            int number;

            //tryparse text as int
            if (!int.TryParse(zipTxt.Text, out number))
            {
                //Stops focus from changing process, will not proceed to validated event
                e.Cancel = true;

                //set error message
                errorProvider1.SetError(zipTxt, "Enter a zip!");

                //Selects inputed text
                zipTxt.SelectAll();
            }
            else
            {
                //Zip has to be 5 digit number within range of zip
                if ((number < minZip) || (number > maxZip) || (zipTxt.Text.Length < 5))
                {
                    //Stops focus from changing process, will not proceed to validated event
                    e.Cancel = true;

                    //set error message
                    errorProvider1.SetError(zipTxt, "Enter valid, 5 digit zip!");

                    //Selects inputed text
                    zipTxt.SelectAll();
                }
            }
        }

        //Precondition: Zip validating sucess
        //Post condition: Error message is cleared
        private void zipTxt_Validated(object sender, EventArgs e)
        {
            //Clears error message
            errorProvider1.SetError(zipTxt, "");
        }

        //Precondition: Attempt to change focus from nametxt
        //Postcondition: If entered value is valid, focus will change, else focus will remain and error provider message set
        private void nameTxt_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(nameTxt.Text))
            {
                //Stops focus from changing process, will not proceed to validated event
                e.Cancel = true;

                //set error message
                errorProvider1.SetError(nameTxt, "Enter name!");

                //Selects inputed text
                nameTxt.SelectAll();
            }
        }

        //Precondition: Name validating sucess
        //Post condition: Error message is cleared
        private void nameTxt_Validated(object sender, EventArgs e)
        {
            //Clears error message
            errorProvider1.SetError(nameTxt, "");
        }

        //Precondition: Attempt to change focus from address1txt
        //Postcondition: If entered value is valid, focus will change, else focus will remain and error provider message set
        private void address1txt_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(address1txt.Text))
            {
                //Stops focus from changing process, will not proceed to validated event
                e.Cancel = true;

                //set error message
                errorProvider1.SetError(nameTxt, "Enter address!");

                //Selects inputed text
                address1txt.SelectAll();
            }
        }

        //Precondition: Address validating sucess
        //Post condition: Error message is cleared
        private void address1txt_Validated(object sender, EventArgs e)
        {
            //Clears error message
            errorProvider1.SetError(nameTxt, "");
        }

        //Precondition: Attempt to change focus from citytxt
        //Postcondition: If entered value is valid, focus will change, else focus will remain and error provider message set
        private void cityTxt_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(cityTxt.Text))
            {
                //Stops focus from changing process, will not proceed to validated event
                e.Cancel = true;

                //set error message
                errorProvider1.SetError(nameTxt, "Enter city!");

                //Selects inputed text
                cityTxt.SelectAll();
            }
        }

        //Precondition: Address validating sucess
        //Post condition: Error message is cleared
        private void cityTxt_Validated(object sender, EventArgs e)
        {
            //Clears error message
            errorProvider1.SetError(nameTxt, "");
        }

        private void stateCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        //Precondition: State combobox is clicked
        //Postcondition: States are shown
        private void AddressForm_Load(object sender, EventArgs e)
        {
            //Combobox
            //List of states
            List<string> states = new List<string> { "CA", "FL", "KY", "NY" };

            // Add states to comboBox
            foreach (string state in states)
            {
                stateCombo.Items.Add(state);
            }
        }

        private void stateCombo_Validating(object sender, CancelEventArgs e)
        {

        }
    }
}
