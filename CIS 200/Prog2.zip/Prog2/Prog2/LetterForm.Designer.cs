﻿namespace Prog2
{
    partial class LetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.oAddressLabel = new System.Windows.Forms.Label();
            this.DAddLabel = new System.Windows.Forms.Label();
            this.fixedCostLabel = new System.Windows.Forms.Label();
            this.oAddressCombo = new System.Windows.Forms.ComboBox();
            this.DAddressCombo = new System.Windows.Forms.ComboBox();
            this.fixedCost = new System.Windows.Forms.TextBox();
            this.OkButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // oAddressLabel
            // 
            this.oAddressLabel.AutoSize = true;
            this.oAddressLabel.Location = new System.Drawing.Point(38, 15);
            this.oAddressLabel.Name = "oAddressLabel";
            this.oAddressLabel.Size = new System.Drawing.Size(78, 13);
            this.oAddressLabel.TabIndex = 0;
            this.oAddressLabel.Text = "Origin Address:";
            // 
            // DAddLabel
            // 
            this.DAddLabel.AutoSize = true;
            this.DAddLabel.Location = new System.Drawing.Point(12, 42);
            this.DAddLabel.Name = "DAddLabel";
            this.DAddLabel.Size = new System.Drawing.Size(104, 13);
            this.DAddLabel.TabIndex = 1;
            this.DAddLabel.Text = "Destination Address:";
            // 
            // fixedCostLabel
            // 
            this.fixedCostLabel.AutoSize = true;
            this.fixedCostLabel.Location = new System.Drawing.Point(57, 69);
            this.fixedCostLabel.Name = "fixedCostLabel";
            this.fixedCostLabel.Size = new System.Drawing.Size(59, 13);
            this.fixedCostLabel.TabIndex = 2;
            this.fixedCostLabel.Text = "Fixed Cost:";
            // 
            // oAddressCombo
            // 
            this.oAddressCombo.FormattingEnabled = true;
            this.oAddressCombo.Location = new System.Drawing.Point(122, 12);
            this.oAddressCombo.Name = "oAddressCombo";
            this.oAddressCombo.Size = new System.Drawing.Size(121, 21);
            this.oAddressCombo.TabIndex = 3;
            // 
            // DAddressCombo
            // 
            this.DAddressCombo.FormattingEnabled = true;
            this.DAddressCombo.Location = new System.Drawing.Point(122, 39);
            this.DAddressCombo.Name = "DAddressCombo";
            this.DAddressCombo.Size = new System.Drawing.Size(121, 21);
            this.DAddressCombo.TabIndex = 4;
            // 
            // fixedCost
            // 
            this.fixedCost.Location = new System.Drawing.Point(122, 66);
            this.fixedCost.Name = "fixedCost";
            this.fixedCost.Size = new System.Drawing.Size(100, 20);
            this.fixedCost.TabIndex = 5;
            this.fixedCost.Validating += new System.ComponentModel.CancelEventHandler(this.fixedCost_Validating);
            this.fixedCost.Validated += new System.EventHandler(this.fixedCost_Validated);
            // 
            // OkButton
            // 
            this.OkButton.Location = new System.Drawing.Point(41, 114);
            this.OkButton.Name = "OkButton";
            this.OkButton.Size = new System.Drawing.Size(75, 23);
            this.OkButton.TabIndex = 6;
            this.OkButton.Text = "OK";
            this.OkButton.UseVisualStyleBackColor = true;
            this.OkButton.Click += new System.EventHandler(this.OkButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(147, 114);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 7;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // LetterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(263, 149);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.OkButton);
            this.Controls.Add(this.fixedCost);
            this.Controls.Add(this.DAddressCombo);
            this.Controls.Add(this.oAddressCombo);
            this.Controls.Add(this.fixedCostLabel);
            this.Controls.Add(this.DAddLabel);
            this.Controls.Add(this.oAddressLabel);
            this.Name = "LetterForm";
            this.Text = "LetterForm";
            this.Load += new System.EventHandler(this.LetterForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label oAddressLabel;
        private System.Windows.Forms.Label DAddLabel;
        private System.Windows.Forms.Label fixedCostLabel;
        private System.Windows.Forms.ComboBox oAddressCombo;
        private System.Windows.Forms.ComboBox DAddressCombo;
        private System.Windows.Forms.TextBox fixedCost;
        private System.Windows.Forms.Button OkButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}