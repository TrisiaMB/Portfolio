﻿//C7032
//Program 0
//Due: 9/11
//CIS 200-01
//Displays origin address, destination address, and cost on console application
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class Program
    {
        static void Main()
        {
            //Makes list of addresses based on Address class
            List<Address> address = new List<Address>();
            address.Add(new Address("Donald Duck", "1313 Webfoot Walk", "Apartment 13", "Duckburg", "KY", 40204));
            address.Add(new Address("Sherlock Holmes", "221B Baker Street", "Apartment 2", "London", "OH", 43002));
            address.Add(new Address("Spongebob Squarepants", "124 Conch Street", "Apartment 3", "Bikini Bottom", "FL", 32003));
            address.Add(new Address("Peter Griffin", "31 Spooner Street", "Apartment 2", "Quohog" , "NY", 10001));

            //Make list of letters based on parce class
            List<Parcel> letters = new List<Parcel>();
            letters.Add(new Letter(address[0], address[1], 100));
            letters.Add(new Letter(address[1], address[2], 200));
            letters.Add(new Letter(address[2], address[3], 300));

            //for each letter (variable L) in letter, display on console
            foreach (Letter L in letters)
            {
                Console.WriteLine(L.ToString() + "\n");
            }
        }
    }
}
