﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    //Class letter is a parcel
    class Letter : Parcel
    {
        private decimal _fixedCost;

        //Addresses derive from Address class
        public Letter(Address originAddress, Address destinationAddress, decimal fixedCosts)
            : base(originAddress, destinationAddress)
        {
            FixedCosts = fixedCosts;
        }
        public decimal FixedCosts
        {
            //Precondition: None
            //Postcondition: Fixed cost is returned
            get
            {
                return _fixedCost;
            }
            set
            //Precondition: None
            //Postcondition: Fixed cost has been set to specified value
            {
                _fixedCost = value;
            }
        }

        //Override calcmethod returns fixed cost
        public override decimal CalcCost()
        {
            return FixedCosts;
        }

        //returns in string form
        public override string ToString()
        {
            //New line shortcut
            String NL = Environment.NewLine;
            return OriginAddress + NL + DestinationAddress + NL + FixedCosts.ToString("C2");
        }
    }
}
