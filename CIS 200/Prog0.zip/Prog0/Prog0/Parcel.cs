﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public abstract class Parcel
    {
        //backing fields
        public Address _originAddress;
        public Address _destinationAddress;

        //Constructor... fields are Address objects
        public Parcel(Address originAddress, Address destinationAddress)
        {
            OriginAddress = originAddress;
            DestinationAddress = destinationAddress;
        }

        public Address OriginAddress
        {
            //Precondition:None
            //Postcondition:Origin Address is returned
            get
            {
                return _originAddress;
            }
            //Precondition: None
            //Postcondition: Origin Address has been set to specified value
            set
            {
                _originAddress = value;
            }
        }
        public Address DestinationAddress
        {
            //Precondition:None
            //Postcondition: Destination Address is returned
            get
            {
                return _destinationAddress;
            }
            //Precondition: None
            //Postcondition: Destination Address has been set to specified value
            set
            {
                _destinationAddress = value;
            }
        }

        //Abstact calculate cost
        public abstract decimal CalcCost();


        //Returns addresses and cost as a string
        public override string ToString()
        {
            //New line shortcut
            string NL = Environment.NewLine;
            return OriginAddress + NL + DestinationAddress + NL + CalcCost().ToString("c2");
        }
    }
}


