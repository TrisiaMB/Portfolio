﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
   public class Address
    {
            //Backing Fields
            private string _name;
            private string _addressLine1;
            private string _addressLine2;
            private string _city;
            private string _state;
            private int _zipCode;

            // minimum zipcode value
            int minZip = 00000;
            //maximum zipcode value
            int maxZip = 99999;

            //Constructor
            public Address(string name, string addressLine1, string addressLine2, string city, string state, int zipCode)
            {
                //Properties
                Name = name;
                Address1 = addressLine1;
                Address2 = addressLine2;
                City = city;
                State = state;
                Zip = zipCode;
            }

            public string Name
            {
                //Precondition: None
                //Postcondition: Zip is returned
                get
                {
                    return _name;
                }

                //Precondition: None
                //Postcondition: Zip code has been set to specified value
                set
                {
                    _name = value;
                }
            }

            public string Address1
            {
                //Precondition: None
                //Postcondition: Address Line 1 is returned
                get
                {
                    return _addressLine1;
                }

                //Pre condition: None
                //Postcondition: Address Line 1 has been set to specified value
                set
                {
                    _addressLine1 = value;
                }
            }

            public string Address2
            {
                //Precondition: None
                //Postcondition: Address Line 2 is returned
                get
                {
                    return _addressLine2;
                }

                //Precondition: None
                //Postcondition: Address Line 2  has been set to specified value
                set
                {
                    _addressLine2 = value;
                }
            }

            public string City
            {
                //Precondition: None
                //Postcondition: City is returned
                get
                {
                    return _city;
                }

                //Precondition: None
                //Postcondition: City has been set to specified value
                set
                {
                    _city = value;
                }
            }

            public string State
            {
                //Precondition: None
                //Postcondition: State is returned
                get
                {
                    return _state;
                }

                //Precondition: None
                //Postcondition: State has been set to specified value
                set
                {
                    _state = value;
                }
            }

            public int Zip
            {
                //Precondition: None
                //Postcondition: Zip is returned
                get
                {
                    return _zipCode;
                }

                //Precondition: None
                //Postcondition: Zip has been set to specified value
                set
                {
                    //Zip has to be more than value of 0 and less than 9999 to be valid
                    if (value >= minZip && value <= maxZip)
                        _zipCode = value;
                    else
                        throw new ArgumentOutOfRangeException("Zip must be a valid 5 digit code");
                }
            }

            public override string ToString()
            {
                //New line shortcut
                string NL = Environment.NewLine;

                if (string.IsNullOrEmpty(Address2))
                    return Name + NL + Address1 + NL + City + NL + State + NL + Zip.ToString("D5");
                else
                    return Name + NL + Address1 + NL + Address2 + NL + City + NL + State + NL + Zip.ToString("D5");
            }
        }
    }

