﻿using System;
using System.Runtime.Serialization;

namespace UPVApp
{
    [Serializable]
    internal class SerilalizableException : Exception
    {
        public SerilalizableException()
        {
        }

        public SerilalizableException(string message) : base(message)
        {
        }

        public SerilalizableException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected SerilalizableException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}