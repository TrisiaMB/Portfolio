﻿namespace UPVApp
{
    internal class RecordSerializable
    {
    }
}