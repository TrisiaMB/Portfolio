﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Program 3
// CIS 200-01
// Fall 2017
// Due: 11/13/17
// By: C7032

namespace Prog2
{
    public partial class ChooseAddress : Form
    {
        public const int MIN_ADDRESSES = 2; // Minimum number of addresses needed

        private List<Address> addressList;  // List of addresses used to fill combo boxes

        public ChooseAddress(List<Address> addresses)
        {
            InitializeComponent();
            addressList = addresses;
        }

        internal int ChooseAddressIndex
        {
            // Precondition:  User has selected from originAddCbo
            // Postcondition: The index of the selected origin address returned
            get
            {
                return chooseAddressCombo.SelectedIndex;
            }
        }

        private void ChooseAddress_Load(object sender, EventArgs e)
        {
            if (addressList.Count < MIN_ADDRESSES) // Violated precondition!
            {
                MessageBox.Show("Need " + MIN_ADDRESSES + " addresses to create letter!",
                    "Addresses Error");
                this.DialogResult = DialogResult.Abort; // Dismiss immediately
            }
            else
            {
                foreach (Address a in addressList)
                {
                    chooseAddressCombo.Items.Add(a.Name);
                }
            }
        }

        private void ChooseAddress_Validating(object sender, CancelEventArgs e)
        {
            //If nothing is selected
            if(chooseAddressCombo.SelectedIndex == -1)
            {
                e.Cancel = true;
                errorProvider1.SetError(chooseAddressCombo, "");
            }
        }

        private void ChooseAddress_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(chooseAddressCombo, "");
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
                this.DialogResult = DialogResult.Cancel;
        }
    }
}
