﻿using System;
using System.Runtime.Serialization;

namespace UPVApp
{
    [Serializable]
    internal class SerializableException : Exception
    {
        public SerializableException()
        {
        }

        public SerializableException(string message) : base(message)
        {
        }

        public SerializableException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected SerializableException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}