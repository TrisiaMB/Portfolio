﻿namespace UPVApp
{
    internal class RecordSerailizable
    {
    }
}