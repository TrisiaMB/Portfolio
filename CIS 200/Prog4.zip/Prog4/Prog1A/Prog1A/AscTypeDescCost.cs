﻿// Program 4
// CIS 200-01/78
// Fall 2017
// Due: 11/27/17
// By: c7032

//Ascending type and descending cost using Icomparer
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
   public class AscTypeDescCost: IComparer<Parcel>
    {
        public int Compare(Parcel p1, Parcel p2)
        {
            //get string type
           string type1 = p1.GetType().ToString();
            string type2 = p2.GetType().ToString();

            if (p1 == null && p2 == null)       //Both null?
                return 0;                       //Equal

            if (p1 == null)                     //only p1 is null?
                return -1;                      //null is less

            if (p2 == null)                     //only p2 null?
                return 1;                       //Any greater 

            if (type1 == type2)                 //Both equal?
                return (p2.CompareTo(p1));        
            return p1.CompareTo(p2);
        }
    }
}
