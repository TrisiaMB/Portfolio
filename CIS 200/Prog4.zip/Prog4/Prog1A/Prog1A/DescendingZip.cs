﻿// Program 4
// CIS 200-01/78
// Fall 2017
// Due: 11/27/17
// By: c7032

//descending zipcode using Icomparer
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
   public class DescendingZip: IComparer<Parcel>
    {
        public int Compare(Parcel p1, Parcel p2)
        {
            if (p1 == null && p2 == null)
                return 0;

            if (p1 == null)
                return -1;

            if (p2 == null)     //only p2 is 
                return 1;

            //Reverses natural order, so descending
            return (-1) * p1.DestinationAddress.Zip.CompareTo(p2.DestinationAddress.Zip);
        }
    }
}
