﻿// Program 1A
// Due" 9/25
// CIS 200-01
//C7032

// File: AirPackage.cs
// Tests if an airpackage is heavy or large
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    //Airpackage class is a package class
    public abstract class AirPackage: Package
    {
        //Constructor
        //Precondition: None
        //Postcondition: Air package is created with specified values
        public AirPackage(Address originAddress, Address destAddress, double length, double width, double height,
            double weight)
            : base(originAddress, destAddress, length, width, height, weight)
        { }

        //If package is heavy
        //Precondition:None
        //Postcondition: Returns if package is heavy
        public Boolean IsHeavy()
        {
            //Minimum weight to determine if package is heavy
            int MIN_WEIGHT = 75;
            if (Weight >= MIN_WEIGHT)
                return true;
            else
                return false;
        }

        //If package is large
        //Precondition: None
        //Postcondition: Returns if package is large
        public Boolean IsLarge()
        {
            //Maximum dimension if package is large
            int MAX_DIMENSION = 100;

            if ((Length + Width + Height) >= MAX_DIMENSION)
                return true;
            else
                return false;
        }

        //Precondition: None
        //Postcondition: A string with Airpackage's data is returned
        public override string ToString()
        {
            //New line short cut 
            string NL = Environment.NewLine;

            //Gets base string 
            string x = base.ToString();
            if (IsHeavy())
                //Adds heavy info into base string
                x += $"{NL}Heavy Package:{IsHeavy()}";

            if (IsLarge())
                //Adds large info into base string
                x += $"{NL}Large Pakage:{IsLarge()}";

            return x;
            
        }

    }
}
