﻿// Program 1A
// Due" 9/25
// CIS 200-01
//C7032

// File: GroundPackage.cs
// Values for ground package.Calculates shipping cost of ground package using zone distance
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    //Class GroundPackage is a package
    public class GroundPackage : Package
    {
        //Constructor
        //Precondition: None
        //Postcondition: Groundpackage is created with specified values
        public GroundPackage(Address originAddress, Address destAddress, double length, double width,
           double height, double weight)
            : base(originAddress, destAddress, length, width, height, weight)
        { }

        public int ZoneDistance
        {
            //Precondition: None
            //Postcondition: Zone distance is returned
            get
            {
                int ZIP_DIVIDER = 10000;
                int zoneDistance;

                zoneDistance = (OriginAddress.Zip / ZIP_DIVIDER) - (DestinationAddress.Zip / ZIP_DIVIDER);

                return zoneDistance;
            }
        }

        // Precondition:  None
        // Postcondition: The parcel's cost has been returned
        public override decimal CalcCost()
        {
            //Precondition: None
            //PostCondition: cost is returned
            double SIZE_MULTIPLIER = .20;
            double ZONE_MULTIPLIER = .05;

            double costInDollars = (SIZE_MULTIPLIER * (Length * Width * Height)) +
                (ZONE_MULTIPLIER * (ZoneDistance + 1) * Weight);

            //Casts cost to decimal
            decimal cost = (decimal)costInDollars;

            return cost;
        }

        // Precondition:  None
        // Postcondition: A String with the parcel's data has been returned
        public override string ToString()
        {
            string NL = Environment.NewLine;    //New Line shortcut

            return $"Ground Package {NL}Origin Address:{NL}{OriginAddress}{NL}{NL}Destination Address:{NL}{DestinationAddress}" +
                $"{NL}{NL}Length:{Length}{NL} Width:{Width}{NL}Height:{Height}{NL}Cost:{CalcCost()}";

        }
    }
}
