﻿// Program 1A
// Due" 9/25
// CIS 200-01
//C7032

// File: NextDayAirpackage.cs
// Based on Airpackage's bool properties. Calculates cost based on those bool properties and adds express fee.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    //Class NextDayAirPackage is a AirPackage
    public class NextDayAirPackage: AirPackage
    {
        //Constructor
        //Precondition: None
        //Postcondition: NextDayAirPackage is created with specified values
        public NextDayAirPackage(Address originAddress, Address destAddress, double length, double width,
            double height, double weight, double expressFee=10)
            : base(originAddress, destAddress, length, width, height, weight)
        { }

        public double ExpressFee
        {
            //Precondition: None
            //Postcondition: Express fee is returned
            get
            {
                return 10;
            }
        }

        //Precondition: None
        //Postcondition: Cost is returned
        public override decimal CalcCost()
        {
            //Used to calculate base cost
            double SIZE_MULTIPLIER = .40; 
            double WEIGHT_MULTIPLIER = .30;

            //If package is heavy, use this multiplier and add to cost
            double HEAVY_MUTLIPLIER = .25;

            //If package is large, use this multiplier and add to cost
            double LARGE_MULTIPLIER = .25;

            //Base cost calculation
            double costInDollars = (SIZE_MULTIPLIER * (Length + Width + Height) + (WEIGHT_MULTIPLIER * Weight)
                + ExpressFee);

            //If package is heavy
            if(IsHeavy())
            {
                costInDollars = costInDollars + (HEAVY_MUTLIPLIER * (Weight));
            }

            //If package is large
            if(IsLarge())
            {
                costInDollars = costInDollars + (LARGE_MULTIPLIER * (Length + Width + Height));
            }

            //Casts cost to decimal
           decimal cost = (decimal)costInDollars;
            return cost;
        }

        // Precondition:  None
        // Postcondition: A String with the next day air package's data has been returned
        public override string ToString()
        {
            string NL = Environment.NewLine;

            return $"Next Day Air Package{NL}Express Fee:{ExpressFee}{NL}{NL}{base.ToString()}{NL}Cost:{CalcCost()}";
        }
    }
}
