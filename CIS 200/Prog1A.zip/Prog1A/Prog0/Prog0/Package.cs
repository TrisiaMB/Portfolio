﻿// Program 1A
// Due" 9/25
// CIS 200-01
//C7032

// File: Package.cs
// Gets and sets package dimensions
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    //Abstract class package is a parcel
    public abstract class Package: Parcel
    {
        //Backing fields
        private double _length;
        private double _width;
        private double _height;
        private double _weight;
        
        //Constructor
        //Precondition: None
        //Postcondition: Package is created with specified values
        public Package (Address originAddress, Address destAddress, double length, double witdth, double height,
            double weight)
            :base (originAddress,destAddress)
        {
            Length = length;
            Width = witdth;
            Height = height;
            Weight = weight;
        }

        public double Length
        {
            //Precondition: None
            //Postcondition: Length is returned
            get
            {
                return _length;
            }
            //Precondition: Length has to be positive
            //Postcondition: Length has been set to specified value
            set
            {
                if (value >= 0)
                    _length = value;
                else
                    throw new ArgumentOutOfRangeException("Length", value, "Length must be 0 or more!");
            }
        }

        public double Width
        {
            //Precondition: None
            //Postcondition:Width is returned
            get
            {
                return _width;
            }
            set
            {
            //Precondition: Width has to be positive
            //Postcondition: Width has been set to specified value
                if (value >= 0)
                    _width = value;
                else
                    throw new ArgumentOutOfRangeException("Width", value, "Width must be 0 or more!");
            }
        }

        public double Height
        {
            //Precondition: None
            //Postcondition: Height is returned
            get
            {
                return _height;
            }
            set
            //Precondition: height has to be positive
            //Postcondition: Height has been set to specified value
            {
                if (value >= 0)
                    _height = value;
                else
                    throw new ArgumentOutOfRangeException("Height", value, "Height must be 0 or more!");
            }
        }

        public double Weight
        {
            //Precondition: None
            //Postcondition: Weight is returned
            get
            {
                return _weight;
            }
            set
            //Precondition:None
            //Postcondition: Weight is set to specified value
            {
                if (value >= 0)
                    _weight = value;
                else
                    throw new ArgumentOutOfRangeException("Weight", value, "Weight must be 0 or more!");
            }
        }

        //Returns package length, width, height, and weight into a string
        public override string ToString()
        {
            string NL = Environment.NewLine;    //New Line shortcut

            return $"Origin Address:{OriginAddress}{NL}{NL}Destination Address:{DestinationAddress}{NL}" +
                $"Length:{Length}{NL}Width:{Width}{NL}Height:{Height}{NL}Weight:{Weight}"; 
        }
    }
}
