﻿// Program 1A
// Due" 9/25
// CIS 200-01
//C7032

// File: TwoDayAirPackage.cs
// Has two enumaration choices for delivery and based on delivery type, shipping cost will change.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    //TwoDayAirPackage is a AirPackage
   public class TwoDayAirPackage: AirPackage
    {
            //Defines 2 choice enumeration for Delivery
            public enum Delivery {Early, Saver};
        
        //Constructor
        //Precondition: None
        //Postcondition: TwoDayAirPackage is created with specified values
        public TwoDayAirPackage (Address originAddress, Address destAddress, double length, double width, double height,
            double weight, Delivery DeliveryType)
            :base(originAddress, destAddress, length, width, height, weight)
        { }
        
        //Property that gets/ sets enum type
        public Delivery DeliveryType
        {
            //Precondition: None
            //Postcondition: DeliveryType is returned
            get;
            //Precondition: None
            //Postconidtion: DeliveryType is set to specified value
            set;
        }

        //Preconidtion: None
        //Postcondition: Cost is returned
        public override decimal CalcCost()
        {
            //Used to calculate base cost
            double SIZE_MULTIPLIER = .25;
            double WEIGHT_MULTIPLIER = .25;

            //Applied if customer is saver
            double SAVER = .10;

            //Calculates base cost
            double costInDollars = (SIZE_MULTIPLIER * (Length + Width + Height) + (WEIGHT_MULTIPLIER * (Weight)));

            //If delivery type is not early
            if (DeliveryType == Delivery.Saver)
            {
                //Cost will be changed using saver
                costInDollars = costInDollars - (costInDollars * SAVER);
            }

            //casts cost to decimal
            decimal cost = (decimal)costInDollars;
            return cost;
        }

        //Precondition: None
        //Postcondition: A string with twodaypackage's data has been returned
        public override string ToString()
        {
            //New line shortcut
            string NL = Environment.NewLine;

            return $"Two Day Air Package{NL}Delivery Type:{DeliveryType}{NL}{base.ToString()}{NL}{NL}Cost:{CalcCost()}";
        }
    }

}
